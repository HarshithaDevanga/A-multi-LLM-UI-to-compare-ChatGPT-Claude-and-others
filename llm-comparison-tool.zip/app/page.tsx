"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import {
  Loader2,
  Sparkles,
  Brain,
  MessageSquare,
  Copy,
  Check,
  Settings,
  Download,
  History,
  Star,
  BarChart3,
  Zap,
  FileText,
  Share2,
  Clock,
  TrendingUp,
  Award,
  Lightbulb,
  RefreshCw,
  BookOpen,
  Target,
  Palette,
  Moon,
  Sun,
} from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface Response {
  chatgpt: string
  claude: string
  timestamp: number
  tokens: { chatgpt: number; claude: number }
  responseTime: { chatgpt: number; claude: number }
}

interface PromptTemplate {
  id: string
  name: string
  category: string
  prompt: string
  description: string
}

interface ComparisonMetrics {
  wordCount: { chatgpt: number; claude: number }
  readabilityScore: { chatgpt: number; claude: number }
  sentiment: { chatgpt: string; claude: string }
  keyTopics: { chatgpt: string[]; claude: string[] }
}

const promptTemplates: PromptTemplate[] = [
  {
    id: "1",
    name: "Technical Explanation",
    category: "Education",
    prompt:
      "Explain [TOPIC] in simple terms that a beginner could understand, including practical examples and common use cases.",
    description: "Perfect for learning new technical concepts",
  },
  {
    id: "2",
    name: "Creative Writing",
    category: "Creative",
    prompt:
      "Write a creative story about [TOPIC] that includes vivid descriptions, compelling characters, and an engaging plot.",
    description: "Generate imaginative stories and narratives",
  },
  {
    id: "3",
    name: "Business Analysis",
    category: "Business",
    prompt:
      "Analyze the business implications of [TOPIC], including market opportunities, potential risks, and strategic recommendations.",
    description: "Professional business insights and analysis",
  },
  {
    id: "4",
    name: "Problem Solving",
    category: "Analysis",
    prompt:
      "Break down this problem: [TOPIC]. Provide a step-by-step solution approach with alternative methods and potential challenges.",
    description: "Systematic problem-solving methodology",
  },
  {
    id: "5",
    name: "Code Review",
    category: "Development",
    prompt:
      "Review this code and provide feedback on: [CODE]. Focus on best practices, performance, security, and maintainability.",
    description: "Professional code analysis and improvement",
  },
]

export default function LLMComparisonTool() {
  const [prompt, setPrompt] = useState("")
  const [responses, setResponses] = useState<Response[]>([])
  const [currentResponse, setCurrentResponse] = useState<Response | null>(null)
  const [loading, setLoading] = useState(false)
  const [copiedStates, setCopiedStates] = useState({ chatgpt: false, claude: false })
  const [selectedTemplate, setSelectedTemplate] = useState<string>("")
  const [darkMode, setDarkMode] = useState(true)
  const [settings, setSettings] = useState({
    temperature: 0.7,
    maxTokens: 1000,
    showMetrics: true,
    autoSave: true,
    realTimeTyping: true,
  })
  const [favorites, setFavorites] = useState<string[]>([])
  const [comparisonMetrics, setComparisonMetrics] = useState<ComparisonMetrics | null>(null)
  const [activeTab, setActiveTab] = useState("compare")
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Simulated typing effect
  const [typingText, setTypingText] = useState({ chatgpt: "", claude: "" })
  const [isTyping, setIsTyping] = useState({ chatgpt: false, claude: false })

  useEffect(() => {
    // Load saved data from localStorage
    const savedResponses = localStorage.getItem("ai-comparison-responses")
    const savedFavorites = localStorage.getItem("ai-comparison-favorites")
    const savedSettings = localStorage.getItem("ai-comparison-settings")

    if (savedResponses) setResponses(JSON.parse(savedResponses))
    if (savedFavorites) setFavorites(JSON.parse(savedFavorites))
    if (savedSettings) setSettings(JSON.parse(savedSettings))
  }, [])

  const simulateTyping = (text: string, model: "chatgpt" | "claude") => {
    setIsTyping((prev) => ({ ...prev, [model]: true }))
    let index = 0
    const interval = setInterval(() => {
      setTypingText((prev) => ({ ...prev, [model]: text.slice(0, index) }))
      index++
      if (index > text.length) {
        clearInterval(interval)
        setIsTyping((prev) => ({ ...prev, [model]: false }))
      }
    }, 30)
  }

  const calculateMetrics = (chatgptResponse: string, claudeResponse: string): ComparisonMetrics => {
    const wordCount = {
      chatgpt: chatgptResponse.split(/\s+/).length,
      claude: claudeResponse.split(/\s+/).length,
    }

    // Simple readability score (Flesch-like)
    const calculateReadability = (text: string) => {
      const sentences = text.split(/[.!?]+/).length
      const words = text.split(/\s+/).length
      const syllables = text.split(/[aeiouAEIOU]/).length
      return Math.max(0, Math.min(100, 206.835 - 1.015 * (words / sentences) - 84.6 * (syllables / words)))
    }

    const readabilityScore = {
      chatgpt: calculateReadability(chatgptResponse),
      claude: calculateReadability(claudeResponse),
    }

    // Simple sentiment analysis
    const analyzeSentiment = (text: string) => {
      const positiveWords = [
        "good",
        "great",
        "excellent",
        "amazing",
        "wonderful",
        "fantastic",
        "positive",
        "beneficial",
      ]
      const negativeWords = [
        "bad",
        "terrible",
        "awful",
        "horrible",
        "negative",
        "problematic",
        "difficult",
        "challenging",
      ]

      const words = text.toLowerCase().split(/\s+/)
      const positiveCount = words.filter((word) => positiveWords.includes(word)).length
      const negativeCount = words.filter((word) => negativeWords.includes(word)).length

      if (positiveCount > negativeCount) return "Positive"
      if (negativeCount > positiveCount) return "Negative"
      return "Neutral"
    }

    const sentiment = {
      chatgpt: analyzeSentiment(chatgptResponse),
      claude: analyzeSentiment(claudeResponse),
    }

    // Extract key topics (simple keyword extraction)
    const extractKeyTopics = (text: string) => {
      const words = text.toLowerCase().split(/\s+/)
      const stopWords = [
        "the",
        "a",
        "an",
        "and",
        "or",
        "but",
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "with",
        "by",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "can",
        "this",
        "that",
        "these",
        "those",
      ]
      const filteredWords = words.filter((word) => word.length > 3 && !stopWords.includes(word))
      const wordFreq = filteredWords.reduce(
        (acc, word) => {
          acc[word] = (acc[word] || 0) + 1
          return acc
        },
        {} as Record<string, number>,
      )

      return Object.entries(wordFreq)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([word]) => word)
    }

    const keyTopics = {
      chatgpt: extractKeyTopics(chatgptResponse),
      claude: extractKeyTopics(claudeResponse),
    }

    return { wordCount, readabilityScore, sentiment, keyTopics }
  }

  const handleCompare = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Please enter a prompt",
        description: "You need to enter a prompt to compare responses.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    setTypingText({ chatgpt: "", claude: "" })
    const startTime = Date.now()

    try {
      const [chatgptRes, claudeRes] = await Promise.allSettled([
        fetch("/api/chatgpt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt,
            temperature: settings.temperature,
            maxTokens: settings.maxTokens,
          }),
        }),
        fetch("/api/claude", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt,
            temperature: settings.temperature,
            maxTokens: settings.maxTokens,
          }),
        }),
      ])

      const chatgptData =
        chatgptRes.status === "fulfilled" ? await chatgptRes.value.json() : { error: "Failed to get ChatGPT response" }
      const claudeData =
        claudeRes.status === "fulfilled" ? await claudeRes.value.json() : { error: "Failed to get Claude response" }

      const endTime = Date.now()
      const responseTime = {
        chatgpt: endTime - startTime,
        claude: endTime - startTime,
      }

      const newResponse: Response = {
        chatgpt: chatgptData.response || `❌ Error: ${chatgptData.error}`,
        claude: claudeData.response || `❌ Error: ${claudeData.error}`,
        timestamp: Date.now(),
        tokens: {
          chatgpt: chatgptData.tokens || 0,
          claude: claudeData.tokens || 0,
        },
        responseTime,
      }

      setCurrentResponse(newResponse)

      // Simulate typing effect if enabled
      if (settings.realTimeTyping) {
        if (chatgptData.response) simulateTyping(chatgptData.response, "chatgpt")
        if (claudeData.response) simulateTyping(claudeData.response, "claude")
      } else {
        setTypingText({
          chatgpt: newResponse.chatgpt,
          claude: newResponse.claude,
        })
      }

      // Calculate comparison metrics
      if (chatgptData.response && claudeData.response) {
        const metrics = calculateMetrics(chatgptData.response, claudeData.response)
        setComparisonMetrics(metrics)
      }

      // Auto-save if enabled
      if (settings.autoSave) {
        const updatedResponses = [newResponse, ...responses.slice(0, 49)] // Keep last 50
        setResponses(updatedResponses)
        localStorage.setItem("ai-comparison-responses", JSON.stringify(updatedResponses))
      }

      toast({
        title: "Responses generated!",
        description: "AI models have provided their responses.",
      })
    } catch (error) {
      console.error("Request error:", error)
      toast({
        title: "Connection Error",
        description: "Failed to connect to AI services. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const applyTemplate = (templateId: string) => {
    const template = promptTemplates.find((t) => t.id === templateId)
    if (template) {
      setPrompt(template.prompt)
      setSelectedTemplate(templateId)
      textareaRef.current?.focus()
    }
  }

  const exportResponse = (format: "pdf" | "markdown" | "json") => {
    if (!currentResponse) return

    const data = {
      prompt,
      responses: currentResponse,
      metrics: comparisonMetrics,
      timestamp: new Date().toISOString(),
    }

    if (format === "json") {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `ai-comparison-${Date.now()}.json`
      a.click()
    } else if (format === "markdown") {
      const markdown = `# AI Comparison Report

## Prompt
${prompt}

## ChatGPT Response
${currentResponse.chatgpt}

## Claude Response
${currentResponse.claude}

## Metrics
- ChatGPT Word Count: ${comparisonMetrics?.wordCount.chatgpt || "N/A"}
- Claude Word Count: ${comparisonMetrics?.wordCount.claude || "N/A"}
- ChatGPT Readability: ${comparisonMetrics?.readabilityScore.chatgpt?.toFixed(1) || "N/A"}
- Claude Readability: ${comparisonMetrics?.readabilityScore.claude?.toFixed(1) || "N/A"}

Generated on: ${new Date().toLocaleString()}
`
      const blob = new Blob([markdown], { type: "text/markdown" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `ai-comparison-${Date.now()}.md`
      a.click()
    }

    toast({
      title: "Export successful!",
      description: `Response exported as ${format.toUpperCase()}.`,
    })
  }

  const copyToClipboard = async (text: string, model: "chatgpt" | "claude") => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedStates((prev) => ({ ...prev, [model]: true }))
      setTimeout(() => {
        setCopiedStates((prev) => ({ ...prev, [model]: false }))
      }, 2000)
      toast({
        title: "Copied!",
        description: `${model === "chatgpt" ? "ChatGPT" : "Claude"} response copied to clipboard.`,
      })
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy text to clipboard.",
        variant: "destructive",
      })
    }
  }

  const toggleFavorite = (responseId: string) => {
    const newFavorites = favorites.includes(responseId)
      ? favorites.filter((id) => id !== responseId)
      : [...favorites, responseId]

    setFavorites(newFavorites)
    localStorage.setItem("ai-comparison-favorites", JSON.stringify(newFavorites))
  }

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        darkMode
          ? "bg-gradient-to-br from-slate-950 via-blue-950 to-indigo-950"
          : "bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50"
      }`}
    >
      {/* Enhanced Background Effects */}
      <div className="absolute inset-0 bg-[url('/grid.png')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]" />
      <div className="absolute inset-0 flex items-center justify-center">
        <div
          className={`h-[50rem] w-[50rem] rounded-full blur-3xl ${
            darkMode
              ? "bg-gradient-to-r from-blue-400/10 via-indigo-400/10 to-purple-400/10"
              : "bg-gradient-to-r from-blue-200/30 via-indigo-200/30 to-purple-200/30"
          }`}
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Enhanced Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="p-3 rounded-2xl bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 shadow-lg">
              <Brain className="h-10 w-10 text-white" />
            </div>
            <div>
              <h1
                className={`text-6xl font-bold bg-gradient-to-r ${
                  darkMode ? "from-white via-blue-200 to-indigo-200" : "from-slate-800 via-blue-600 to-indigo-600"
                } bg-clip-text text-transparent`}
              >
                AI Nexus Pro
              </h1>
              <p className="text-sm text-blue-400 font-medium mt-1">Professional AI Comparison Platform</p>
            </div>
          </div>
          <p className={`text-xl max-w-3xl mx-auto leading-relaxed ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
            Advanced AI model comparison with real-time analysis, professional metrics, and enterprise-grade features.
            Compare <span className="text-emerald-400 font-semibold">ChatGPT</span> and
            <span className="text-amber-400 font-semibold"> Claude</span> with scientific precision.
          </p>
        </div>

        {/* Main Interface */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList
            className={`grid w-full grid-cols-4 ${
              darkMode ? "bg-slate-800/50" : "bg-white/70"
            } backdrop-blur-lg border-0 shadow-lg`}
          >
            <TabsTrigger value="compare" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Compare
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              History
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="compare" className="space-y-6">
            {/* Enhanced Input Section */}
            <Card
              className={`${
                darkMode ? "bg-slate-900/40 border-slate-700/50" : "bg-white/60 border-slate-200/50"
              } backdrop-blur-xl shadow-2xl`}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className={`flex items-center gap-3 ${darkMode ? "text-white" : "text-slate-800"}`}>
                    <MessageSquare className="h-6 w-6 text-blue-500" />
                    Prompt Engineering Studio
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDarkMode(!darkMode)}
                      className={darkMode ? "text-slate-300" : "text-slate-600"}
                    >
                      {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" className={darkMode ? "text-slate-300" : "text-slate-600"}>
                          <Settings className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className={darkMode ? "bg-slate-900 border-slate-700" : "bg-white"}>
                        <DialogHeader>
                          <DialogTitle>Advanced Settings</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-6">
                          <div>
                            <Label>Temperature: {settings.temperature}</Label>
                            <Slider
                              value={[settings.temperature]}
                              onValueChange={([value]) => setSettings((prev) => ({ ...prev, temperature: value }))}
                              max={2}
                              min={0}
                              step={0.1}
                              className="mt-2"
                            />
                          </div>
                          <div>
                            <Label>Max Tokens: {settings.maxTokens}</Label>
                            <Slider
                              value={[settings.maxTokens]}
                              onValueChange={([value]) => setSettings((prev) => ({ ...prev, maxTokens: value }))}
                              max={4000}
                              min={100}
                              step={100}
                              className="mt-2"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label>Show Metrics</Label>
                            <Switch
                              checked={settings.showMetrics}
                              onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, showMetrics: checked }))}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label>Auto Save</Label>
                            <Switch
                              checked={settings.autoSave}
                              onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, autoSave: checked }))}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label>Real-time Typing</Label>
                            <Switch
                              checked={settings.realTimeTyping}
                              onCheckedChange={(checked) =>
                                setSettings((prev) => ({ ...prev, realTimeTyping: checked }))
                              }
                            />
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  ref={textareaRef}
                  placeholder="Enter your prompt here... Use [TOPIC] or [CODE] placeholders when using templates."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className={`min-h-[140px] text-lg resize-none transition-all duration-200 ${
                    darkMode
                      ? "bg-slate-800/50 border-slate-600/50 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20"
                      : "bg-white/50 border-slate-300/50 text-slate-800 placeholder:text-slate-500 focus:border-blue-500 focus:ring-blue-500/20"
                  }`}
                  disabled={loading}
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {prompt.length} characters
                    </Badge>
                    {selectedTemplate && (
                      <Badge variant="outline" className="text-xs">
                        Template: {promptTemplates.find((t) => t.id === selectedTemplate)?.name}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPrompt("")}
                      disabled={loading || !prompt}
                      className={darkMode ? "border-slate-600 text-slate-300" : "border-slate-300 text-slate-600"}
                    >
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Clear
                    </Button>
                    <Button
                      onClick={handleCompare}
                      disabled={loading || !prompt.trim()}
                      className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 text-white font-semibold px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-200"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Sparkles className="mr-2 h-5 w-5" />
                          Compare AI Models
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Enhanced Responses Section */}
            <div className="grid lg:grid-cols-2 gap-6">
              {/* ChatGPT Response */}
              <Card
                className={`${
                  darkMode
                    ? "bg-gradient-to-br from-emerald-950/30 to-green-950/30 border-emerald-500/30"
                    : "bg-gradient-to-br from-emerald-50/80 to-green-50/80 border-emerald-200/50"
                } backdrop-blur-xl shadow-2xl`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-emerald-500/20 backdrop-blur-sm">
                        <Brain className="h-6 w-6 text-emerald-400" />
                      </div>
                      <div>
                        <CardTitle className="text-emerald-400 text-xl">ChatGPT Response</CardTitle>
                        <p className="text-xs text-emerald-300/70 mt-1">OpenAI GPT-4 Turbo</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
                        GPT-4
                      </Badge>
                      {currentResponse && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(currentResponse.chatgpt, "chatgpt")}
                            className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                          >
                            {copiedStates.chatgpt ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleFavorite(`${currentResponse.timestamp}-chatgpt`)}
                            className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                          >
                            <Star
                              className={`h-4 w-4 ${favorites.includes(`${currentResponse.timestamp}-chatgpt`) ? "fill-current" : ""}`}
                            />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div
                    className={`min-h-[400px] p-6 rounded-xl border transition-all duration-200 ${
                      darkMode ? "bg-slate-900/40 border-emerald-500/20" : "bg-white/60 border-emerald-200/30"
                    }`}
                  >
                    {loading ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="flex flex-col items-center gap-3 text-emerald-400">
                          <Loader2 className="h-8 w-8 animate-spin" />
                          <span className="text-sm">ChatGPT is thinking...</span>
                          <Progress value={33} className="w-32" />
                        </div>
                      </div>
                    ) : typingText.chatgpt ? (
                      <div className="space-y-4">
                        <p
                          className={`leading-relaxed whitespace-pre-wrap ${
                            darkMode ? "text-slate-200" : "text-slate-700"
                          }`}
                        >
                          {typingText.chatgpt}
                          {isTyping.chatgpt && <span className="animate-pulse">|</span>}
                        </p>
                        {settings.showMetrics && comparisonMetrics && (
                          <div className="pt-4 border-t border-emerald-500/20">
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-emerald-400 font-medium">Words:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {comparisonMetrics.wordCount.chatgpt}
                                </span>
                              </div>
                              <div>
                                <span className="text-emerald-400 font-medium">Readability:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {comparisonMetrics.readabilityScore.chatgpt.toFixed(1)}
                                </span>
                              </div>
                              <div>
                                <span className="text-emerald-400 font-medium">Sentiment:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {comparisonMetrics.sentiment.chatgpt}
                                </span>
                              </div>
                              <div>
                                <span className="text-emerald-400 font-medium">Response Time:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {currentResponse?.responseTime.chatgpt}ms
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <p className={`italic text-center ${darkMode ? "text-slate-500" : "text-slate-400"}`}>
                          ChatGPT response will appear here...
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Claude Response */}
              <Card
                className={`${
                  darkMode
                    ? "bg-gradient-to-br from-amber-950/30 to-orange-950/30 border-amber-500/30"
                    : "bg-gradient-to-br from-amber-50/80 to-orange-50/80 border-amber-200/50"
                } backdrop-blur-xl shadow-2xl`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-amber-500/20 backdrop-blur-sm">
                        <Brain className="h-6 w-6 text-amber-400" />
                      </div>
                      <div>
                        <CardTitle className="text-amber-400 text-xl">Claude Response</CardTitle>
                        <p className="text-xs text-amber-300/70 mt-1">Anthropic Claude-3 Sonnet</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-amber-500/20 text-amber-300 border-amber-500/30">
                        Claude-3
                      </Badge>
                      {currentResponse && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(currentResponse.claude, "claude")}
                            className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
                          >
                            {copiedStates.claude ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleFavorite(`${currentResponse.timestamp}-claude`)}
                            className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
                          >
                            <Star
                              className={`h-4 w-4 ${favorites.includes(`${currentResponse.timestamp}-claude`) ? "fill-current" : ""}`}
                            />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div
                    className={`min-h-[400px] p-6 rounded-xl border transition-all duration-200 ${
                      darkMode ? "bg-slate-900/40 border-amber-500/20" : "bg-white/60 border-amber-200/30"
                    }`}
                  >
                    {loading ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="flex flex-col items-center gap-3 text-amber-400">
                          <Loader2 className="h-8 w-8 animate-spin" />
                          <span className="text-sm">Claude is processing...</span>
                          <Progress value={66} className="w-32" />
                        </div>
                      </div>
                    ) : typingText.claude ? (
                      <div className="space-y-4">
                        <p
                          className={`leading-relaxed whitespace-pre-wrap ${
                            darkMode ? "text-slate-200" : "text-slate-700"
                          }`}
                        >
                          {typingText.claude}
                          {isTyping.claude && <span className="animate-pulse">|</span>}
                        </p>
                        {settings.showMetrics && comparisonMetrics && (
                          <div className="pt-4 border-t border-amber-500/20">
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-amber-400 font-medium">Words:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {comparisonMetrics.wordCount.claude}
                                </span>
                              </div>
                              <div>
                                <span className="text-amber-400 font-medium">Readability:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {comparisonMetrics.readabilityScore.claude.toFixed(1)}
                                </span>
                              </div>
                              <div>
                                <span className="text-amber-400 font-medium">Sentiment:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {comparisonMetrics.sentiment.claude}
                                </span>
                              </div>
                              <div>
                                <span className="text-amber-400 font-medium">Response Time:</span>
                                <span className={`ml-2 ${darkMode ? "text-slate-300" : "text-slate-600"}`}>
                                  {currentResponse?.responseTime.claude}ms
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <p className={`italic text-center ${darkMode ? "text-slate-500" : "text-slate-400"}`}>
                          Claude response will appear here...
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Export and Actions */}
            {currentResponse && (
              <Card
                className={`${
                  darkMode ? "bg-slate-900/40 border-slate-700/50" : "bg-white/60 border-slate-200/50"
                } backdrop-blur-xl`}
              >
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Award className="h-5 w-5 text-blue-400" />
                      <span className={`font-medium ${darkMode ? "text-white" : "text-slate-800"}`}>
                        Export & Share
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportResponse("markdown")}
                        className={darkMode ? "border-slate-600 text-slate-300" : "border-slate-300 text-slate-600"}
                      >
                        <FileText className="h-4 w-4 mr-1" />
                        Markdown
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportResponse("json")}
                        className={darkMode ? "border-slate-600 text-slate-300" : "border-slate-300 text-slate-600"}
                      >
                        <Download className="h-4 w-4 mr-1" />
                        JSON
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          navigator.share?.({
                            title: "AI Comparison Result",
                            text: `Prompt: ${prompt}\n\nChatGPT: ${currentResponse.chatgpt}\n\nClaude: ${currentResponse.claude}`,
                          }) || toast({ title: "Sharing not supported", variant: "destructive" })
                        }}
                        className={darkMode ? "border-slate-600 text-slate-300" : "border-slate-300 text-slate-600"}
                      >
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <Card
              className={`${
                darkMode ? "bg-slate-900/40 border-slate-700/50" : "bg-white/60 border-slate-200/50"
              } backdrop-blur-xl`}
            >
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${darkMode ? "text-white" : "text-slate-800"}`}>
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  Prompt Templates
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {promptTemplates.map((template) => (
                    <Card
                      key={template.id}
                      className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                        darkMode
                          ? "bg-slate-800/50 border-slate-600/50 hover:border-blue-500/50"
                          : "bg-white/70 border-slate-200/50 hover:border-blue-400/50"
                      }`}
                      onClick={() => applyTemplate(template.id)}
                    >
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <h3 className={`font-semibold ${darkMode ? "text-white" : "text-slate-800"}`}>
                              {template.name}
                            </h3>
                            <Badge variant="outline" className="text-xs">
                              {template.category}
                            </Badge>
                          </div>
                          <p className={`text-sm ${darkMode ? "text-slate-400" : "text-slate-600"}`}>
                            {template.description}
                          </p>
                          <p className={`text-xs font-mono ${darkMode ? "text-slate-500" : "text-slate-500"} truncate`}>
                            {template.prompt}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card
              className={`${
                darkMode ? "bg-slate-900/40 border-slate-700/50" : "bg-white/60 border-slate-200/50"
              } backdrop-blur-xl`}
            >
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${darkMode ? "text-white" : "text-slate-800"}`}>
                  <Clock className="h-5 w-5 text-blue-500" />
                  Response History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {responses.length === 0 ? (
                  <p className={`text-center py-8 ${darkMode ? "text-slate-400" : "text-slate-500"}`}>
                    No responses saved yet. Enable auto-save in settings to track your comparisons.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {responses.slice(0, 10).map((response, index) => (
                      <Card
                        key={response.timestamp}
                        className={`${
                          darkMode ? "bg-slate-800/30 border-slate-600/30" : "bg-white/50 border-slate-200/30"
                        }`}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className={`text-sm ${darkMode ? "text-slate-400" : "text-slate-500"}`}>
                              {new Date(response.timestamp).toLocaleString()}
                            </span>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {response.tokens.chatgpt + response.tokens.claude} tokens
                              </Badge>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setCurrentResponse(response)
                                  setTypingText({ chatgpt: response.chatgpt, claude: response.claude })
                                  setActiveTab("compare")
                                }}
                                className={darkMode ? "text-slate-300" : "text-slate-600"}
                              >
                                <Target className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          <div className="grid md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className={`font-medium text-emerald-400 mb-1`}>ChatGPT</p>
                              <p className={`${darkMode ? "text-slate-300" : "text-slate-600"} line-clamp-3`}>
                                {response.chatgpt.substring(0, 150)}...
                              </p>
                            </div>
                            <div>
                              <p className={`font-medium text-amber-400 mb-1`}>Claude</p>
                              <p className={`${darkMode ? "text-slate-300" : "text-slate-600"} line-clamp-3`}>
                                {response.claude.substring(0, 150)}...
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card
                className={`${
                  darkMode
                    ? "bg-gradient-to-br from-blue-950/50 to-indigo-950/50 border-blue-500/30"
                    : "bg-gradient-to-br from-blue-50/80 to-indigo-50/80 border-blue-200/50"
                } backdrop-blur-xl`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="h-8 w-8 text-blue-400" />
                    <div>
                      <p className={`text-2xl font-bold ${darkMode ? "text-white" : "text-slate-800"}`}>
                        {responses.length}
                      </p>
                      <p className={`text-sm ${darkMode ? "text-slate-400" : "text-slate-500"}`}>Total Comparisons</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card
                className={`${
                  darkMode
                    ? "bg-gradient-to-br from-emerald-950/50 to-green-950/50 border-emerald-500/30"
                    : "bg-gradient-to-br from-emerald-50/80 to-green-50/80 border-emerald-200/50"
                } backdrop-blur-xl`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Award className="h-8 w-8 text-emerald-400" />
                    <div>
                      <p className={`text-2xl font-bold ${darkMode ? "text-white" : "text-slate-800"}`}>
                        {favorites.length}
                      </p>
                      <p className={`text-sm ${darkMode ? "text-slate-400" : "text-slate-500"}`}>Favorites Saved</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card
                className={`${
                  darkMode
                    ? "bg-gradient-to-br from-purple-950/50 to-pink-950/50 border-purple-500/30"
                    : "bg-gradient-to-br from-purple-50/80 to-pink-50/80 border-purple-200/50"
                } backdrop-blur-xl`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Zap className="h-8 w-8 text-purple-400" />
                    <div>
                      <p className={`text-2xl font-bold ${darkMode ? "text-white" : "text-slate-800"}`}>
                        {responses.reduce((acc, r) => acc + r.tokens.chatgpt + r.tokens.claude, 0)}
                      </p>
                      <p className={`text-sm ${darkMode ? "text-slate-400" : "text-slate-500"}`}>Total Tokens</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card
                className={`${
                  darkMode
                    ? "bg-gradient-to-br from-amber-950/50 to-orange-950/50 border-amber-500/30"
                    : "bg-gradient-to-br from-amber-50/80 to-orange-50/80 border-amber-200/50"
                } backdrop-blur-xl`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Clock className="h-8 w-8 text-amber-400" />
                    <div>
                      <p className={`text-2xl font-bold ${darkMode ? "text-white" : "text-slate-800"}`}>
                        {responses.length > 0
                          ? Math.round(
                              responses.reduce((acc, r) => acc + r.responseTime.chatgpt + r.responseTime.claude, 0) /
                                (responses.length * 2),
                            )
                          : 0}
                        ms
                      </p>
                      <p className={`text-sm ${darkMode ? "text-slate-400" : "text-slate-500"}`}>Avg Response Time</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Enhanced Footer */}
        <div className="text-center mt-16 space-y-4">
          <div className="flex items-center justify-center gap-6">
            <Badge
              variant="outline"
              className={`${darkMode ? "border-slate-600 text-slate-400" : "border-slate-300 text-slate-500"}`}
            >
              <Palette className="h-3 w-3 mr-1" />
              Research-Based Colors
            </Badge>
            <Badge
              variant="outline"
              className={`${darkMode ? "border-slate-600 text-slate-400" : "border-slate-300 text-slate-500"}`}
            >
              <Brain className="h-3 w-3 mr-1" />
              AI-Powered Analytics
            </Badge>
            <Badge
              variant="outline"
              className={`${darkMode ? "border-slate-600 text-slate-400" : "border-slate-300 text-slate-500"}`}
            >
              <Award className="h-3 w-3 mr-1" />
              Enterprise Grade
            </Badge>
          </div>
          <p className={`${darkMode ? "text-slate-400" : "text-slate-500"}`}>
            Built with Next.js 14, TypeScript, Tailwind CSS, and shadcn/ui • Color psychology research applied
          </p>
        </div>
      </div>
    </div>
  )
}
