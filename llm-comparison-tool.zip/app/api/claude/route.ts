import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Check if Claude API key is configured
    if (!process.env.CLAUDE_API_KEY) {
      return NextResponse.json(
        {
          error: "Claude API key not configured. Please add CLAUDE_API_KEY to your environment variables.",
        },
        { status: 500 },
      )
    }

    // Check if the API key looks like a valid Claude key (starts with 'sk-ant-')
    if (!process.env.CLAUDE_API_KEY.startsWith("sk-ant-")) {
      return NextResponse.json(
        {
          error:
            "Invalid Claude API key format. Claude API keys should start with 'sk-ant-'. Please get a valid key from https://console.anthropic.com/",
        },
        { status: 500 },
      )
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.CLAUDE_API_KEY}`,
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-sonnet-20240229",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Claude API Error:", errorData)

      // Handle specific error types
      if (errorData.error?.type === "authentication_error") {
        return NextResponse.json(
          {
            error:
              "Invalid Claude API key. Please check your CLAUDE_API_KEY in the environment variables. Get a valid key from https://console.anthropic.com/",
          },
          { status: 401 },
        )
      }

      if (errorData.error?.type === "rate_limit_error") {
        return NextResponse.json(
          {
            error: "Claude API rate limit exceeded. Please try again later.",
          },
          { status: 429 },
        )
      }

      return NextResponse.json(
        {
          error: `Claude API Error: ${errorData.error?.message || "Unknown error"}`,
        },
        { status: response.status },
      )
    }

    const data = await response.json()
    const aiResponse = data.content[0]?.text || "No response generated"

    return NextResponse.json({ response: aiResponse })
  } catch (error) {
    console.error("Claude API Error:", error)
    return NextResponse.json(
      {
        error: "Failed to connect to Claude API. Please check your internet connection and API key.",
      },
      { status: 500 },
    )
  }
}
